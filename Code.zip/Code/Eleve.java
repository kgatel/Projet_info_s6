public class Eleve extends Utilisateur{
	
	//meme attributs
	
	public Eleve(){
		super();
	}
	
	public Eleve(String Prenom, String Nom, String Login, String Mdp){
		super(Prenom,Nom,Login,Mdp);
	}
	
	//meme accesseurs
	
	//methodes

}

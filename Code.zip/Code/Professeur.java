public class Professeur extends Utilisateur{
	
	//meme attributs
	
	public Professeur(){
		super();
	}
	
	public Professeur(String Prenom, String Nom, String Login, String Mdp){
		super(Prenom,Nom,Login,Mdp);
	}
	
	//meme accesseurs
	
	//methodes

}
